


function signout(element) {
    element.innerText = "signout";
}

function hide(element) {
    element.remove();
}

function Alert() {
    alert("I am an alert box!");
}

