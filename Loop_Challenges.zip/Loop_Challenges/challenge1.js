


// Print odds 1-20
// Using a loop write code that will console.log all of the odd values from 1 up to 20.

for ( var x = 1; x < 21; x ++){
    if (x % 2 == 1){
        console.log(x);
    }
}