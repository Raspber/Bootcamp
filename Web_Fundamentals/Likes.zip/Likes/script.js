var count = 3;
var countElement = document.querySelector("#count")

function add1(){
    countElement.innerText = count + "likes";

    count ++;

}